import javax.swing.*;



    public class HelloWorld {


        public static void main(String[] args) {
            JFrame frame = new JFrame("Hello World");

            frame.add(new JLabel("Hello World"));

            frame.setSize(200, 100);
            frame.setLocationRelativeTo(null);

            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

            // Show the frame
            frame.setVisible(true);
        }
    }

